﻿Imports System.IO
Imports System.Text
Public Class FrmReports
    'AUTHOR: Thomas Khai Tran
    'DATE: 19/3/21
    'TITLE: U3O1 Part II Folio SAC

    '--sets Validation boolean as false by default and defines SelectedRating for later use
    Dim blnInputDataOK = False
    Dim SelectedState As String

    '--when basic list all customer details button is clicked, displays contents of textfile via streamreader
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnListAllCustomerDetails.Click
        lsbCustomerList.Items.Clear()
        Dim CustomerDetails As StreamReader = File.OpenText("CustomerDetails.txt")
        Dim custGivenName As String
        Dim custSurname As String
        Dim custStreetAdress As String
        Dim custSuburb As String
        Dim custPostCode As Integer
        Dim custMobileNum As Integer
        Dim custRating As String
        '--opens textfile loops through data until complete
        Do While CustomerDetails.Peek <> -1
            custGivenName = CustomerDetails.ReadLine()
            custSurname = CustomerDetails.ReadLine()
            custStreetAdress = CustomerDetails.ReadLine()
            custSuburb = CustomerDetails.ReadLine()
            custPostCode = CustomerDetails.ReadLine()
            custMobileNum = CustomerDetails.ReadLine()
            custRating = CustomerDetails.ReadLine()
            '--outputs data to listbox 
            lsbCustomerList.Items.Add(Name & ", " & Rating & ", " & Year())
        Loop
        '--closes file
        Names1File.Close()
    End Sub

    '--when sort button is clicked, runs DoSelection & DoValidation subroutine, then DoActions subroutine if data is correct
    Private Sub btnRating_Click(sender As Object, e As EventArgs) Handles btnListCustByState.Click
        blnInputDataOK = False
        DoSelection()
        DoValidation()
        'checks if IF statements in DoValidation subroutine are fulfilled and runs DoActions
        If blnInputDataOK = True Then
            DoActionSelection()
        End If
    End Sub

    '--saves value of combobox selection via Select Case
    Private Sub DoSelection()
        SelectedState = cbxStates.SelectedItem
        '--uses Select Case to assign value
        Select Case SelectedState
            Case "VIC"
                SelectedState = ("VIC")
            Case "NSW"
                SelectedState = ("NSW")
            Case "QLD"
                SelectedState = ("QLD")
            Case "NT"
                SelectedState = ("NT")
            Case "WA"
                SelectedState = ("WA")
            Case "SA"
                SelectedState = ("SA")

            Case Else
                SelectedState = ("Valid Rating Not Found")
        End Select
    End Sub

    '--validates combobox selection via IF statement
    Private Sub DoValidation()
        '--existence check
        If (String.IsNullOrEmpty(cbxStates.Text)) Then
            MessageBox.Show("Enter a state", "Error")
            cbxStates.Focus()
        Else
            blnInputDataOK = True
        End If
    End Sub

    '-- sorted action subroutine reads file and uses IF statement for sort
    Private Sub DoActionSelection()
        'Reads file
        lsbCustomerList.Items.Clear()
        Dim Names1File As StreamReader = File.OpenText("CustomerDetails.txt")
        Dim Name As String
        Dim Rating As String
        Dim Year As String
        '--loops through textfile 
        Do While Names1File.Peek <> -1
            Name = Names1File.ReadLine()
            Rating = Names1File.ReadLine
            Year = Names1File.ReadLine
            '--IF statement checking if selected combobox rating matches data input and outputs if matches 
            If Rating = SelectedState Then
                lsbCustomerList.Items.Add(Name & ", " & Rating & ", " & Year)
            End If
        Loop
        Names1File.Close()
    End Sub


End Class