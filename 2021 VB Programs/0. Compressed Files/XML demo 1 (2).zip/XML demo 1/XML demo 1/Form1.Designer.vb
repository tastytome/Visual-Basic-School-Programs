﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.txtBirthdate = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lsbBirthdates = New System.Windows.Forms.ListBox()
        Me.lsbCountires = New System.Windows.Forms.ListBox()
        Me.lsbNames = New System.Windows.Forms.ListBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Show2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lsbCommon = New System.Windows.Forms.ListBox()
        Me.lsbBotanical = New System.Windows.Forms.ListBox()
        Me.lsbZone = New System.Windows.Forms.ListBox()
        Me.lsbLight = New System.Windows.Forms.ListBox()
        Me.lsbAvail = New System.Windows.Forms.ListBox()
        Me.lsbPrice = New System.Windows.Forms.ListBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lsbPublish = New System.Windows.Forms.ListBox()
        Me.lsbDescription = New System.Windows.Forms.ListBox()
        Me.lsbPriceB = New System.Windows.Forms.ListBox()
        Me.lsbGenre = New System.Windows.Forms.ListBox()
        Me.lsbTitle = New System.Windows.Forms.ListBox()
        Me.lsbAuthor = New System.Windows.Forms.ListBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnDeleteNode = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(131, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(277, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Tennis Dream Team"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(201, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(120, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Add New Player"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(60, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Player Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(93, 99)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Country"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(78, 125)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Birth Date"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(164, 73)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(192, 20)
        Me.txtName.TabIndex = 5
        '
        'txtCountry
        '
        Me.txtCountry.Location = New System.Drawing.Point(165, 99)
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.Size = New System.Drawing.Size(191, 20)
        Me.txtCountry.TabIndex = 6
        '
        'txtBirthdate
        '
        Me.txtBirthdate.Location = New System.Drawing.Point(165, 125)
        Me.txtBirthdate.Name = "txtBirthdate"
        Me.txtBirthdate.Size = New System.Drawing.Size(190, 20)
        Me.txtBirthdate.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(361, 127)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(145, 18)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "enter as dd-mm-yyyy"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(84, 151)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 9
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(205, 154)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 10
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(316, 155)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(75, 23)
        Me.btnShow.TabIndex = 11
        Me.btnShow.Text = "Show"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(142, 209)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(227, 31)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Player Summary"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lsbBirthdates)
        Me.GroupBox1.Controls.Add(Me.lsbCountires)
        Me.GroupBox1.Controls.Add(Me.lsbNames)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Location = New System.Drawing.Point(64, 236)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(396, 172)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        '
        'lsbBirthdates
        '
        Me.lsbBirthdates.FormattingEnabled = True
        Me.lsbBirthdates.Location = New System.Drawing.Point(279, 48)
        Me.lsbBirthdates.Name = "lsbBirthdates"
        Me.lsbBirthdates.Size = New System.Drawing.Size(101, 108)
        Me.lsbBirthdates.TabIndex = 5
        '
        'lsbCountires
        '
        Me.lsbCountires.FormattingEnabled = True
        Me.lsbCountires.Location = New System.Drawing.Point(157, 48)
        Me.lsbCountires.Name = "lsbCountires"
        Me.lsbCountires.Size = New System.Drawing.Size(116, 108)
        Me.lsbCountires.TabIndex = 4
        '
        'lsbNames
        '
        Me.lsbNames.FormattingEnabled = True
        Me.lsbNames.Location = New System.Drawing.Point(18, 48)
        Me.lsbNames.Name = "lsbNames"
        Me.lsbNames.Size = New System.Drawing.Size(133, 108)
        Me.lsbNames.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(286, 20)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "BIRTHDATE"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(154, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "COUNTRY"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(18, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "NAME"
        '
        'Show2
        '
        Me.Show2.Location = New System.Drawing.Point(375, 212)
        Me.Show2.Name = "Show2"
        Me.Show2.Size = New System.Drawing.Size(75, 23)
        Me.Show2.TabIndex = 14
        Me.Show2.Text = "Show"
        Me.Show2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(600, 47)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 23)
        Me.Button1.TabIndex = 15
        Me.Button1.Text = "Display Plants"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'lsbCommon
        '
        Me.lsbCommon.FormattingEnabled = True
        Me.lsbCommon.Location = New System.Drawing.Point(585, 86)
        Me.lsbCommon.Name = "lsbCommon"
        Me.lsbCommon.Size = New System.Drawing.Size(164, 43)
        Me.lsbCommon.TabIndex = 16
        '
        'lsbBotanical
        '
        Me.lsbBotanical.FormattingEnabled = True
        Me.lsbBotanical.Location = New System.Drawing.Point(585, 142)
        Me.lsbBotanical.Name = "lsbBotanical"
        Me.lsbBotanical.Size = New System.Drawing.Size(163, 43)
        Me.lsbBotanical.TabIndex = 17
        '
        'lsbZone
        '
        Me.lsbZone.FormattingEnabled = True
        Me.lsbZone.Location = New System.Drawing.Point(585, 192)
        Me.lsbZone.Name = "lsbZone"
        Me.lsbZone.Size = New System.Drawing.Size(164, 43)
        Me.lsbZone.TabIndex = 18
        '
        'lsbLight
        '
        Me.lsbLight.FormattingEnabled = True
        Me.lsbLight.Location = New System.Drawing.Point(584, 241)
        Me.lsbLight.Name = "lsbLight"
        Me.lsbLight.Size = New System.Drawing.Size(164, 43)
        Me.lsbLight.TabIndex = 19
        '
        'lsbAvail
        '
        Me.lsbAvail.FormattingEnabled = True
        Me.lsbAvail.Location = New System.Drawing.Point(585, 339)
        Me.lsbAvail.Name = "lsbAvail"
        Me.lsbAvail.Size = New System.Drawing.Size(164, 43)
        Me.lsbAvail.TabIndex = 20
        '
        'lsbPrice
        '
        Me.lsbPrice.FormattingEnabled = True
        Me.lsbPrice.Location = New System.Drawing.Point(585, 290)
        Me.lsbPrice.Name = "lsbPrice"
        Me.lsbPrice.Size = New System.Drawing.Size(164, 43)
        Me.lsbPrice.TabIndex = 21
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(512, 102)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 13)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "COMMON"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(512, 152)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(67, 13)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "BOTANICAL"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(524, 202)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(37, 13)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "ZONE"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(524, 255)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(39, 13)
        Me.Label14.TabIndex = 25
        Me.Label14.Text = "LIGHT"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(524, 300)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(39, 13)
        Me.Label15.TabIndex = 26
        Me.Label15.Text = "PRICE"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(524, 339)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(37, 13)
        Me.Label16.TabIndex = 27
        Me.Label16.Text = "AVAIL"
        '
        'lsbPublish
        '
        Me.lsbPublish.FormattingEnabled = True
        Me.lsbPublish.Location = New System.Drawing.Point(771, 290)
        Me.lsbPublish.Name = "lsbPublish"
        Me.lsbPublish.Size = New System.Drawing.Size(169, 43)
        Me.lsbPublish.TabIndex = 33
        '
        'lsbDescription
        '
        Me.lsbDescription.FormattingEnabled = True
        Me.lsbDescription.Location = New System.Drawing.Point(771, 339)
        Me.lsbDescription.Name = "lsbDescription"
        Me.lsbDescription.Size = New System.Drawing.Size(169, 43)
        Me.lsbDescription.TabIndex = 32
        '
        'lsbPriceB
        '
        Me.lsbPriceB.FormattingEnabled = True
        Me.lsbPriceB.Location = New System.Drawing.Point(770, 241)
        Me.lsbPriceB.Name = "lsbPriceB"
        Me.lsbPriceB.Size = New System.Drawing.Size(169, 43)
        Me.lsbPriceB.TabIndex = 31
        '
        'lsbGenre
        '
        Me.lsbGenre.FormattingEnabled = True
        Me.lsbGenre.Location = New System.Drawing.Point(771, 192)
        Me.lsbGenre.Name = "lsbGenre"
        Me.lsbGenre.Size = New System.Drawing.Size(169, 43)
        Me.lsbGenre.TabIndex = 30
        '
        'lsbTitle
        '
        Me.lsbTitle.FormattingEnabled = True
        Me.lsbTitle.Location = New System.Drawing.Point(771, 142)
        Me.lsbTitle.Name = "lsbTitle"
        Me.lsbTitle.Size = New System.Drawing.Size(168, 43)
        Me.lsbTitle.TabIndex = 29
        '
        'lsbAuthor
        '
        Me.lsbAuthor.FormattingEnabled = True
        Me.lsbAuthor.Location = New System.Drawing.Point(771, 86)
        Me.lsbAuthor.Name = "lsbAuthor"
        Me.lsbAuthor.Size = New System.Drawing.Size(169, 43)
        Me.lsbAuthor.TabIndex = 28
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(782, 47)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(128, 23)
        Me.Button2.TabIndex = 34
        Me.Button2.Text = "Display Books"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(85, 185)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 35
        Me.Button3.Text = "Append"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnDeleteNode
        '
        Me.btnDeleteNode.Location = New System.Drawing.Point(166, 185)
        Me.btnDeleteNode.Name = "btnDeleteNode"
        Me.btnDeleteNode.Size = New System.Drawing.Size(73, 23)
        Me.btnDeleteNode.TabIndex = 36
        Me.btnDeleteNode.Text = "Delete"
        Me.btnDeleteNode.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(972, 420)
        Me.Controls.Add(Me.btnDeleteNode)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.lsbPublish)
        Me.Controls.Add(Me.lsbDescription)
        Me.Controls.Add(Me.lsbPriceB)
        Me.Controls.Add(Me.lsbGenre)
        Me.Controls.Add(Me.lsbTitle)
        Me.Controls.Add(Me.lsbAuthor)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.lsbPrice)
        Me.Controls.Add(Me.lsbAvail)
        Me.Controls.Add(Me.lsbLight)
        Me.Controls.Add(Me.lsbZone)
        Me.Controls.Add(Me.lsbBotanical)
        Me.Controls.Add(Me.lsbCommon)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Show2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtBirthdate)
        Me.Controls.Add(Me.txtCountry)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtCountry As System.Windows.Forms.TextBox
    Friend WithEvents txtBirthdate As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnShow As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lsbBirthdates As System.Windows.Forms.ListBox
    Friend WithEvents lsbCountires As System.Windows.Forms.ListBox
    Friend WithEvents lsbNames As System.Windows.Forms.ListBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Show2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents lsbCommon As System.Windows.Forms.ListBox
    Friend WithEvents lsbBotanical As System.Windows.Forms.ListBox
    Friend WithEvents lsbZone As System.Windows.Forms.ListBox
    Friend WithEvents lsbLight As System.Windows.Forms.ListBox
    Friend WithEvents lsbAvail As System.Windows.Forms.ListBox
    Friend WithEvents lsbPrice As System.Windows.Forms.ListBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lsbPublish As System.Windows.Forms.ListBox
    Friend WithEvents lsbDescription As System.Windows.Forms.ListBox
    Friend WithEvents lsbPriceB As System.Windows.Forms.ListBox
    Friend WithEvents lsbGenre As System.Windows.Forms.ListBox
    Friend WithEvents lsbTitle As System.Windows.Forms.ListBox
    Friend WithEvents lsbAuthor As System.Windows.Forms.ListBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents btnDeleteNode As System.Windows.Forms.Button

End Class
