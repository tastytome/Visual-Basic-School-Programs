﻿Imports System.IO
Imports System.Text
Public Class Form1
    Dim Toydct As Dictionary(Of String, String) = New Dictionary(Of String, String)()
    'source: https://www.tutlane.com/tutorial/visual-basic/vb-dictionary
    Private Sub BtnDictionary_Click(sender As Object, e As EventArgs) Handles BtnDictionary.Click
        ' Create a new dictionary with int keys and string values.
        Dim dct As Dictionary(Of Integer, String) = New Dictionary(Of Integer, String)()
        ' Add elements to the dictionary object
        ' No duplicate keys allowed but values can be duplicate
        dct.Add(1, "Suresh")
        dct.Add(4, "Rohini")
        dct.Add(2, "Trishi")
        dct.Add(3, Nothing)
        ' Another way to add elements.
        ' If key Not exist, then that key adds a new key/value pair.
        dct(5) = "Trishi"
        ' Add method throws an exception if key already in the dictionary
        Try
            dct.Add(2, "Praveen")
        Catch __unusedArgumentException1__ As ArgumentException
            ListBox1.Items.Add("An element with Key = '2' already exists.")
        End Try
        ListBox1.Items.Add("*********Dictionary1 Elements********")
        ' Accessing elements as KeyValuePair objects
        For Each item As KeyValuePair(Of Integer, String) In dct
            ListBox1.Items.Add("Key = {0}, Value = {1}" & " " & item.Key & " " & item.Value)
        Next
        ' Creating and initializing dictionary
        Dim dct2 As Dictionary(Of String, Integer?) = New Dictionary(Of String, Integer?) From {
                {"msg2", 1},
                {"msg3", 20},
                {"msg4", 100},
                {"msg1", Nothing}
            }
        ListBox1.Items.Add("*********Dictionary2 Elements********")
        ' Accessing elements as KeyValuePair objects
        For Each item As KeyValuePair(Of String, Integer?) In dct2
            ListBox1.Items.Add("Key = {0}, Value = {1}" & " " & item.Key & " " & item.Value)
        Next

    End Sub

    Private Sub btnAccess_Click(sender As Object, e As EventArgs) Handles btnAccess.Click
        ' Create a new dictionary
        Dim dct As Dictionary(Of Integer, String) = New Dictionary(Of Integer, String)()
        dct.Add(1, "Suresh")
        dct.Add(4, "Rohini")
        dct.Add(2, "Trishi")
        dct.Add(3, "Praveen")
        ' Access value with key (not index)
        Dim val1 As String = dct(2)
        Dim val2 As String = dct(3)
        Dim val3 As String = dct(4)
        ListBox1.Items.Add("******Access Elements with Keys*****")
        ListBox1.Items.Add("Value at Key '2': " & val1)
        ListBox1.Items.Add("Value at Key '3': " & val2)
        ListBox1.Items.Add("Value at Key '4': " & val3)
        ListBox1.Items.Add("*********Access Elements with Foreach Loop********")
        For Each item As KeyValuePair(Of Integer, String) In dct
            ListBox1.Items.Add("Key = {0}, Value = {1}" & " " & item.Key & " " & item.Value)
        Next
        ListBox1.Items.Add("*********Dictionary Keys********")
        For Each item In dct.Keys
            ListBox1.Items.Add("Key = {0}" & " " & item)
        Next
        ListBox1.Items.Add("*********Dictionary Values********")
        For Each item In dct.Values
            ListBox1.Items.Add("Value = {0}" & " " & item)
        Next
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        ' Create a new dictionary

        Dim dct As Dictionary(Of Integer, String) = New Dictionary(Of Integer, String)()
        dct.Add(1, "Suresh")
        dct.Add(4, "Rohini")
        dct.Add(2, "Trishi")
        dct.Add(3, "Praveen")
        dct.Add(5, "Sateesh")

        ' Remove element with key (not index)
        dct.Remove(3)
        dct.Remove(5)
        ListBox1.Items.Add("*********Access Dictionary Elements********")
        ListBox1.Items.Add("")
        For Each item As KeyValuePair(Of Integer, String) In dct
            ListBox1.Items.Add("Key = {0}, Value = {1}" & " " & item.Key & " " & item.Value)
        Next
    End Sub

    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        ' Create a new dictionary
        Dim dct As Dictionary(Of Integer, String) = New Dictionary(Of Integer, String)()
        dct.Add(1, "Suresh")
        dct.Add(4, "Rohini")
        dct.Add(2, "Trishi")
        dct.Add(3, "Praveen")
        dct.Add(5, "Sateesh")
        ListBox1.Items.Add("Contains Key 2: {0}" & " " & dct.ContainsKey(2))
        ListBox1.Items.Add("Contains Value 'Tutlane': {0}" & " " & dct.ContainsValue("Tutlane"))
        ListBox1.Items.Add("")
    End Sub

    Private Sub btnPopulate_Click(sender As Object, e As EventArgs) Handles btnPopulate.Click
        Dim ToysFIle As StreamReader = File.OpenText("ToyList.txt")
        Dim Tname As String
        Do While ToysFIle.Peek <> -1
            Tname = ToysFIle.ReadLine()
            cbxToysList.Items.Add(Tname)
        Loop
        ToysFIle.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim ToysFIle As StreamReader = File.OpenText("ToyList.txt")
        Dim Tname As String
        Do While ToysFIle.Peek <> -1
            Tname = ToysFIle.ReadLine()
            cbxToysList.Items.Add(Tname)
        Loop
        ToysFIle.Close()
    End Sub

    Private Sub BtnBorrowToy_Click(sender As Object, e As EventArgs) Handles BtnBorrowToy.Click
        Try
            Toydct.Add(cbxToysList.SelectedItem, cbxMembersList.SelectedItem)
        Catch __unusedArgumentException1__ As ArgumentException
            ListBox1.Items.Add("An element with Key = " & cbxToysList.SelectedItem & " already exists.")
        End Try
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Try
            Toydct.Remove(cbxToysList.SelectedItem, cbxMembersList.SelectedItem)
        Catch ex As Exception
            MessageBox.Show("That toy has not been borrowed")
        End Try
    End Sub

    Private Sub BtnDisplayBorrowedToys_Click(sender As Object, e As EventArgs) Handles BtnDisplayBorrowedToys.Click
        ListBox1.Items.Clear()

        ListBox1.Items.Add("*********Access Dictionary Elements********")
        ListBox1.Items.Add("")
        For Each item As KeyValuePair(Of String, String) In Toydct
            ListBox1.Items.Add(item.Key & " " & item.Value)
        Next
    End Sub

    Private Sub btnCheckToy_Click(sender As Object, e As EventArgs) Handles btnCheckToy.Click
        Dim ToyBorrowed As String = InputBox("Enter the key borrowed", "ToyBorrowed Toy")
        Dim Toyindex As Integer
        For Each item As KeyValuePair(Of String, String) In Toydct
            If item.Key = ToyBorrowed Then
                Toypos = Toyindex
            End If
        Next
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ListBox1.Items.Clear()
        txbBorrowerName.Text = Nothing
        cbxToysList.Text = Nothing
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        '--Exit button to close down the application, with an Are You Sure message 
        Dim confirm_msg As Integer
        confirm_msg = MessageBox.Show("Are you sure you want to exit?", "Exit and Close",
                      MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If confirm_msg = vbYes Then
            Me.Close()
        Else
            Exit Sub
        End If
    End Sub

End Class

'' Create a new dictionary with int keys and string values.
''Dim dct As Dictionary(Of String, String) = New Dictionary(Of String, String)()

' Add method throws an exception if key already in the dictionary
'Try
'Toydct.Add(cbxToysList.SelectedItem, txbBorrowerName.Text)
'Catch __unusedArgumentException1__ As ArgumentException
'ListBox1.Items.Add("An element with Key = " & CbxToysList.SelectedItem & " already exists.")
'End Try