﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDictionary = New System.Windows.Forms.Button()
        Me.btnAccess = New System.Windows.Forms.Button()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.btnPopulate = New System.Windows.Forms.Button()
        Me.btnBorrowToy = New System.Windows.Forms.Button()
        Me.btnDisplayBorrowedToys = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbxToysList = New System.Windows.Forms.ComboBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnReturn = New System.Windows.Forms.Button()
        Me.cbxMembersList = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.cbxCheckToy = New System.Windows.Forms.ComboBox()
        Me.btnCheckToy = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnDictionary
        '
        Me.btnDictionary.Location = New System.Drawing.Point(12, 30)
        Me.btnDictionary.Name = "btnDictionary"
        Me.btnDictionary.Size = New System.Drawing.Size(123, 23)
        Me.btnDictionary.TabIndex = 0
        Me.btnDictionary.Text = "DictionaryGo"
        Me.btnDictionary.UseVisualStyleBackColor = True
        '
        'btnAccess
        '
        Me.btnAccess.Location = New System.Drawing.Point(12, 79)
        Me.btnAccess.Name = "btnAccess"
        Me.btnAccess.Size = New System.Drawing.Size(123, 23)
        Me.btnAccess.TabIndex = 1
        Me.btnAccess.Text = "Access Items"
        Me.btnAccess.UseVisualStyleBackColor = True
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(12, 108)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(123, 23)
        Me.btnRemove.TabIndex = 2
        Me.btnRemove.Text = "Remove Items"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'btnCheck
        '
        Me.btnCheck.Location = New System.Drawing.Point(12, 137)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(123, 23)
        Me.btnCheck.TabIndex = 3
        Me.btnCheck.Text = "Check If Item Exists"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'btnPopulate
        '
        Me.btnPopulate.Location = New System.Drawing.Point(12, 185)
        Me.btnPopulate.Name = "btnPopulate"
        Me.btnPopulate.Size = New System.Drawing.Size(123, 73)
        Me.btnPopulate.TabIndex = 4
        Me.btnPopulate.Text = "Populate ComboBox From Textfile"
        Me.btnPopulate.UseVisualStyleBackColor = True
        '
        'btnBorrowToy
        '
        Me.btnBorrowToy.Location = New System.Drawing.Point(21, 185)
        Me.btnBorrowToy.Name = "btnBorrowToy"
        Me.btnBorrowToy.Size = New System.Drawing.Size(101, 23)
        Me.btnBorrowToy.TabIndex = 5
        Me.btnBorrowToy.Text = "Borrow Toy"
        Me.btnBorrowToy.UseVisualStyleBackColor = True
        '
        'btnDisplayBorrowedToys
        '
        Me.btnDisplayBorrowedToys.Location = New System.Drawing.Point(21, 213)
        Me.btnDisplayBorrowedToys.Name = "btnDisplayBorrowedToys"
        Me.btnDisplayBorrowedToys.Size = New System.Drawing.Size(209, 44)
        Me.btnDisplayBorrowedToys.TabIndex = 6
        Me.btnDisplayBorrowedToys.Text = "Display List Of Toys"
        Me.btnDisplayBorrowedToys.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 15)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Enter Your Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(197, 15)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Select a Toy from the Dropdown List"
        '
        'cbxToysList
        '
        Me.cbxToysList.FormattingEnabled = True
        Me.cbxToysList.Items.AddRange(New Object() {"bicycle.", "train.", "doll.", "ball.", "teddy bear.", "kite.", "rubber ducky.", "airplane"})
        Me.cbxToysList.Location = New System.Drawing.Point(21, 106)
        Me.cbxToysList.Name = "cbxToysList"
        Me.cbxToysList.Size = New System.Drawing.Size(209, 23)
        Me.cbxToysList.TabIndex = 10
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 15
        Me.ListBox1.Location = New System.Drawing.Point(13, 20)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(252, 244)
        Me.ListBox1.TabIndex = 11
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(604, 40)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(70, 23)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(4, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(672, 37)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Associative Array Dictionary                            Banana"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(528, 40)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(70, 23)
        Me.btnClear.TabIndex = 14
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnPopulate)
        Me.GroupBox1.Controls.Add(Me.btnDictionary)
        Me.GroupBox1.Controls.Add(Me.btnAccess)
        Me.GroupBox1.Controls.Add(Me.btnRemove)
        Me.GroupBox1.Controls.Add(Me.btnCheck)
        Me.GroupBox1.Location = New System.Drawing.Point(36, 68)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(150, 288)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnReturn)
        Me.GroupBox2.Controls.Add(Me.cbxMembersList)
        Me.GroupBox2.Controls.Add(Me.cbxToysList)
        Me.GroupBox2.Controls.Add(Me.btnBorrowToy)
        Me.GroupBox2.Controls.Add(Me.btnDisplayBorrowedToys)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Location = New System.Drawing.Point(192, 68)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(247, 288)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        '
        'btnReturn
        '
        Me.btnReturn.Location = New System.Drawing.Point(128, 185)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(102, 23)
        Me.btnReturn.TabIndex = 12
        Me.btnReturn.Text = "Return Toy"
        Me.btnReturn.UseVisualStyleBackColor = True
        '
        'cbxMembersList
        '
        Me.cbxMembersList.FormattingEnabled = True
        Me.cbxMembersList.Items.AddRange(New Object() {"Anna", "Barry", "Craig", "David", "Ella", "Frank", "Girthy", "Hilda", "Isla", "Jenny", "Kare"})
        Me.cbxMembersList.Location = New System.Drawing.Point(21, 47)
        Me.cbxMembersList.Name = "cbxMembersList"
        Me.cbxMembersList.Size = New System.Drawing.Size(209, 23)
        Me.cbxMembersList.TabIndex = 11
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ListBox1)
        Me.GroupBox3.Location = New System.Drawing.Point(445, 68)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(282, 288)
        Me.GroupBox3.TabIndex = 17
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Location = New System.Drawing.Point(36, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(691, 61)
        Me.GroupBox4.TabIndex = 18
        Me.GroupBox4.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.cbxCheckToy)
        Me.GroupBox5.Controls.Add(Me.btnExit)
        Me.GroupBox5.Controls.Add(Me.btnClear)
        Me.GroupBox5.Controls.Add(Me.btnCheckToy)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Location = New System.Drawing.Point(36, 362)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(691, 87)
        Me.GroupBox5.TabIndex = 17
        Me.GroupBox5.TabStop = False
        '
        'cbxCheckToy
        '
        Me.cbxCheckToy.FormattingEnabled = True
        Me.cbxCheckToy.Items.AddRange(New Object() {"Anna", "Barry", "Craig", "David", "Ella", "Frank", "Girthy", "Hilda", "Isla", "Jenny", "Kare"})
        Me.cbxCheckToy.Location = New System.Drawing.Point(21, 40)
        Me.cbxCheckToy.Name = "cbxCheckToy"
        Me.cbxCheckToy.Size = New System.Drawing.Size(209, 23)
        Me.cbxCheckToy.TabIndex = 11
        '
        'btnCheckToy
        '
        Me.btnCheckToy.Location = New System.Drawing.Point(236, 40)
        Me.btnCheckToy.Name = "btnCheckToy"
        Me.btnCheckToy.Size = New System.Drawing.Size(123, 23)
        Me.btnCheckToy.TabIndex = 5
        Me.btnCheckToy.Text = "Check Toy"
        Me.btnCheckToy.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(21, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(125, 15)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Check If Toy Borrowed"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.ClientSize = New System.Drawing.Size(752, 466)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Dictionary"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnDictionary As Button
    Friend WithEvents btnAccess As Button
    Friend WithEvents btnRemove As Button
    Friend WithEvents btnCheck As Button
    Friend WithEvents btnPopulate As Button
    Friend WithEvents btnBorrowToy As Button
    Friend WithEvents btnDisplayBorrowedToys As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txbBorrowerName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cbxToysList As ComboBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents btnExit As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents cbxMembersList As ComboBox
    Friend WithEvents btnReturn As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents cbxCheckToy As ComboBox
    Friend WithEvents btnCheckToy As Button
    Friend WithEvents Label4 As Label
End Class
